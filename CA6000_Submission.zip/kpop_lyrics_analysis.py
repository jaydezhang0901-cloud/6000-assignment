# -*- coding: utf-8 -*-
"""
CA6000 Assignment: K-Pop Girl Group Lyrics Analysis
Neural Network-based Generation Prediction Model

Author: [Your Name]
Date: December 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ============================================
# SECTION 1: DATA IMPORT
# ============================================
def load_data(filepath):
    """Load and return the dataset"""
    print("="*60)
    print("SECTION 1: DATA IMPORT")
    print("="*60)
    
    df = pd.read_csv(filepath, encoding='utf-8-sig')
    print(f"Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns")
    print(f"Columns: {df.columns.tolist()}")
    
    return df

# ============================================
# SECTION 2: ERROR DETECTION AND CLEANING
# ============================================
def introduce_errors(df):
    """Introduce errors for demonstration purposes"""
    print("\n" + "="*60)
    print("SECTION 2: ERROR DETECTION AND CLEANING")
    print("="*60)
    
    df_with_errors = df.copy()
    np.random.seed(42)
    
    print("\n2.1 Original Missing Values:")
    missing = df.isnull().sum()
    for col in df.columns:
        if missing[col] > 0:
            print(f"   {col}: {missing[col]}")
    
    print("\n2.2 Introducing Errors (for demonstration):")
    
    # Error 1: NaN in lyrics (5%)
    nan_idx = np.random.choice(df_with_errors.index, size=int(len(df_with_errors)*0.05), replace=False)
    df_with_errors.loc[nan_idx, 'lyrics'] = np.nan
    print(f"   - Added {len(nan_idx)} NaN values to 'lyrics'")
    
    # Error 2: NaN in artist (3%)
    nan_artist = np.random.choice(df_with_errors.index, size=int(len(df_with_errors)*0.03), replace=False)
    df_with_errors.loc[nan_artist, 'artist'] = np.nan
    print(f"   - Added {len(nan_artist)} NaN values to 'artist'")
    
    # Error 3: Duplicates
    dups = df_with_errors.sample(n=50, random_state=42)
    df_with_errors = pd.concat([df_with_errors, dups], ignore_index=True)
    print(f"   - Added 50 duplicate rows")
    
    # Error 4: Invalid values
    invalid_idx = np.random.choice(df_with_errors.index, size=10, replace=False)
    df_with_errors.loc[invalid_idx, 'year'] = 'invalid'
    print(f"   - Added 10 invalid year values")
    
    # Error 5: Outliers
    outlier_idx = np.random.choice(df_with_errors.index, size=15, replace=False)
    df_with_errors.loc[outlier_idx[:8], 'lyrics_length'] = 99999
    df_with_errors.loc[outlier_idx[8:], 'lyrics_length'] = -100
    print(f"   - Added 15 outliers to 'lyrics_length'")
    
    print(f"\nDataset after errors: {len(df_with_errors)} rows")
    
    return df_with_errors

def detect_errors(df):
    """Detect errors in the dataset"""
    print("\n2.3 Error Detection:")
    print(f"   Missing values: {df.isnull().sum().sum()}")
    print(f"   Duplicate rows: {df.duplicated().sum()}")
    
    df['year_numeric'] = pd.to_numeric(df['year'], errors='coerce')
    invalid_years = df['year_numeric'].isna().sum() - df['year'].isna().sum()
    print(f"   Invalid year values: {invalid_years}")
    
    return df

def clean_data(df):
    """Clean the dataset using Pandas functions"""
    print("\n2.4 Cleaning Process:")
    df_clean = df.copy()
    
    # Fix 1: Remove duplicates
    before = len(df_clean)
    df_clean = df_clean.drop_duplicates()
    print(f"   1. Removed {before - len(df_clean)} duplicates (df.drop_duplicates())")
    
    # Fix 2: Remove NaN lyrics
    before = len(df_clean)
    df_clean = df_clean.dropna(subset=['lyrics'])
    print(f"   2. Removed {before - len(df_clean)} rows with NaN lyrics (df.dropna())")
    
    # Fix 3: Remove NaN artist
    before = len(df_clean)
    df_clean = df_clean.dropna(subset=['artist'])
    print(f"   3. Removed {before - len(df_clean)} rows with NaN artist")
    
    # Fix 4: Fix invalid year
    df_clean['year'] = pd.to_numeric(df_clean['year'], errors='coerce')
    before = len(df_clean)
    df_clean = df_clean.dropna(subset=['year'])
    df_clean['year'] = df_clean['year'].astype(int)
    print(f"   4. Removed {before - len(df_clean)} rows with invalid year (pd.to_numeric)")
    
    # Fix 5: Recalculate lyrics_length and remove outliers
    df_clean['lyrics_length'] = df_clean['lyrics'].apply(lambda x: len(str(x)))
    before = len(df_clean)
    df_clean = df_clean[(df_clean['lyrics_length'] >= 50) & (df_clean['lyrics_length'] <= 5000)]
    print(f"   5. Removed {before - len(df_clean)} outliers (Boolean indexing)")
    
    # Drop temp column
    if 'year_numeric' in df_clean.columns:
        df_clean = df_clean.drop(columns=['year_numeric'])
    
    return df_clean

# ============================================
# SECTION 3: STATISTICAL SUMMARY
# ============================================
def print_statistics(df):
    """Print statistical summary of the dataset"""
    print("\n" + "="*60)
    print("SECTION 3: STATISTICAL SUMMARY")
    print("="*60)
    
    print("\n3.1 Numerical Statistics:")
    for col in ['year', 'lyrics_length']:
        print(f"\n   {col.upper()}:")
        print(f"      Mean:     {df[col].mean():.2f}")
        print(f"      Median:   {df[col].median():.2f}")
        print(f"      Std Dev:  {df[col].std():.2f}")
        print(f"      Variance: {df[col].var():.2f}")
        print(f"      Min:      {df[col].min()}")
        print(f"      Max:      {df[col].max()}")
    
    print("\n3.2 Generation Distribution (Target Variable):")
    gen_counts = df['generation'].value_counts()
    for gen in ['一代', '二代', '三代', '四代', '五代', '六代']:
        if gen in gen_counts.index:
            pct = gen_counts[gen] / len(df) * 100
            print(f"   {gen}: {gen_counts[gen]:4d} songs ({pct:.1f}%)")
    
    return gen_counts

# ============================================
# SECTION 4: DATA PREPROCESSING
# ============================================
def clean_text(text):
    """Clean lyrics text for model input"""
    if not isinstance(text, str):
        return ""
    text = ' '.join(text.split())
    text = re.sub(r'[^가-힣a-zA-Z\s]', '', text)
    return text.strip()

def preprocess_data(df):
    """Preprocess data for neural network"""
    print("\n" + "="*60)
    print("SECTION 4: DATA PREPROCESSING")
    print("="*60)
    
    # Text cleaning
    df['lyrics_cleaned'] = df['lyrics'].apply(clean_text)
    df = df[df['lyrics_cleaned'].str.len() > 10]
    
    # Prepare features and target
    X = df['lyrics_cleaned'].values
    y = df['generation'].values
    
    # Label encoding
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    
    print(f"4.1 Data Preparation:")
    print(f"   Total samples: {len(X)}")
    print(f"   Classes: {label_encoder.classes_.tolist()}")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )
    print(f"   Training set: {len(X_train)} samples")
    print(f"   Test set: {len(X_test)} samples")
    
    # TF-IDF
    print(f"\n4.2 Feature Extraction (TF-IDF):")
    tfidf = TfidfVectorizer(max_features=3000, ngram_range=(1,2), min_df=2)
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)
    print(f"   Feature dimension: {X_train_tfidf.shape[1]}")
    
    return X_train_tfidf, X_test_tfidf, y_train, y_test, label_encoder, tfidf

# ============================================
# SECTION 5: NEURAL NETWORK TRAINING
# ============================================
def train_model(X_train, y_train):
    """Train the neural network model"""
    print("\n" + "="*60)
    print("SECTION 5: NEURAL NETWORK TRAINING")
    print("="*60)
    
    print("\n5.1 Model Architecture:")
    print("   Model: MLPClassifier (sklearn)")
    print("   Hidden layers: (256, 128, 64)")
    print("   Activation: ReLU")
    print("   Solver: Adam")
    print("   Early stopping: Yes")
    
    model = MLPClassifier(
        hidden_layer_sizes=(256, 128, 64),
        activation='relu',
        solver='adam',
        max_iter=200,
        early_stopping=True,
        validation_fraction=0.1,
        random_state=42,
        verbose=False
    )
    
    print("\n5.2 Training...")
    model.fit(X_train, y_train)
    
    print(f"   Training completed!")
    print(f"   Iterations: {model.n_iter_}")
    print(f"   Best validation score: {model.best_validation_score_:.4f}")
    
    return model

# ============================================
# SECTION 6: EVALUATION
# ============================================
def evaluate_model(model, X_test, y_test, label_encoder):
    """Evaluate the trained model"""
    print("\n" + "="*60)
    print("SECTION 6: MODEL EVALUATION")
    print("="*60)
    
    # Predictions
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n╔══════════════════════════════════════╗")
    print(f"║  TEST ACCURACY: {accuracy:.4f} ({accuracy*100:.2f}%)   ║")
    print(f"╚══════════════════════════════════════╝")
    
    print(f"\n6.1 Classification Report:")
    print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))
    
    print("6.2 Per-Class Accuracy:")
    for i, label in enumerate(label_encoder.classes_):
        mask = y_test == i
        if mask.sum() > 0:
            class_acc = (y_pred[mask] == i).sum() / mask.sum()
            print(f"   {label}: {class_acc:.4f} ({class_acc*100:.1f}%)")
    
    return y_pred, accuracy

# ============================================
# SECTION 7: VISUALIZATION
# ============================================
def create_visualizations(df, y_test, y_pred, label_encoder, model):
    """Create and save visualizations"""
    print("\n" + "="*60)
    print("SECTION 7: VISUALIZATION")
    print("="*60)
    
    gen_counts = df['generation'].value_counts()
    gen_order = ['一代', '二代', '三代', '四代', '五代', '六代']
    gen_labels = ['Gen1', 'Gen2', 'Gen3', 'Gen4', 'Gen5', 'Gen6']
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # 1. Generation distribution
    counts = [gen_counts.get(g, 0) for g in gen_order]
    colors = plt.cm.viridis(np.linspace(0, 1, 6))
    axes[0,0].bar(gen_labels, counts, color=colors)
    axes[0,0].set_xlabel('Generation')
    axes[0,0].set_ylabel('Number of Songs')
    axes[0,0].set_title('Song Distribution by Generation')
    for i, v in enumerate(counts):
        axes[0,0].text(i, v+5, str(v), ha='center')
    
    # 2. Lyrics length distribution
    axes[0,1].hist(df['lyrics_length'], bins=40, color='steelblue', edgecolor='black', alpha=0.7)
    axes[0,1].axvline(df['lyrics_length'].mean(), color='red', linestyle='--', 
                      label=f"Mean: {df['lyrics_length'].mean():.0f}")
    axes[0,1].axvline(df['lyrics_length'].median(), color='green', linestyle='--', 
                      label=f"Median: {df['lyrics_length'].median():.0f}")
    axes[0,1].set_xlabel('Lyrics Length (chars)')
    axes[0,1].set_ylabel('Frequency')
    axes[0,1].set_title('Distribution of Lyrics Length')
    axes[0,1].legend()
    
    # 3. Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[1,0],
                xticklabels=gen_labels, yticklabels=gen_labels)
    axes[1,0].set_xlabel('Predicted')
    axes[1,0].set_ylabel('Actual')
    axes[1,0].set_title('Confusion Matrix')
    
    # 4. Per-class accuracy
    class_accs = []
    for i in range(len(label_encoder.classes_)):
        mask = y_test == i
        if mask.sum() > 0:
            class_accs.append((y_pred[mask] == i).sum() / mask.sum())
        else:
            class_accs.append(0)
    
    bars = axes[1,1].bar(gen_labels, class_accs, 
                         color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#9B59B6'])
    axes[1,1].set_xlabel('Generation')
    axes[1,1].set_ylabel('Accuracy')
    axes[1,1].set_title('Per-Class Accuracy')
    axes[1,1].set_ylim(0, 1)
    for bar, acc in zip(bars, class_accs):
        axes[1,1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
                       f'{acc:.2f}', ha='center', fontsize=10)
    
    plt.tight_layout()
    plt.savefig('analysis_results.png', dpi=150, bbox_inches='tight')
    print("Saved: analysis_results.png")
    
    # Training curve
    fig2, ax = plt.subplots(figsize=(8, 5))
    ax.plot(model.loss_curve_, color='blue', linewidth=2)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Loss')
    ax.set_title('Training Loss Curve')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('training_curve.png', dpi=150, bbox_inches='tight')
    print("Saved: training_curve.png")
    
    plt.show()

# ============================================
# MAIN FUNCTION
# ============================================
def main():
    """Main function to run the complete analysis"""
    print("\n" + "="*60)
    print("CA6000 ASSIGNMENT - K-POP GIRL GROUP LYRICS ANALYSIS")
    print("="*60)
    
    # Step 1: Load data
    df_original = load_data('girlgroup_songs.csv')
    
    # Step 2: Introduce and clean errors
    df_with_errors = introduce_errors(df_original)
    df_with_errors = detect_errors(df_with_errors)
    df_clean = clean_data(df_with_errors)
    
    print(f"\n2.5 Cleaning Summary:")
    print(f"   Original (with errors): {len(df_with_errors)} rows")
    print(f"   After cleaning: {len(df_clean)} rows")
    print(f"   Removed: {len(df_with_errors) - len(df_clean)} rows ({(len(df_with_errors)-len(df_clean))/len(df_with_errors)*100:.1f}%)")
    
    # Step 3: Statistical summary
    gen_counts = print_statistics(df_clean)
    
    # Step 4: Preprocess data
    X_train, X_test, y_train, y_test, label_encoder, tfidf = preprocess_data(df_clean)
    
    # Step 5: Train model
    model = train_model(X_train, y_train)
    
    # Step 6: Evaluate model
    y_pred, accuracy = evaluate_model(model, X_test, y_test, label_encoder)
    
    # Step 7: Create visualizations
    create_visualizations(df_clean, y_test, y_pred, label_encoder, model)
    
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE!")
    print("="*60)
    
    return model, accuracy

if __name__ == "__main__":
    model, accuracy = main()
